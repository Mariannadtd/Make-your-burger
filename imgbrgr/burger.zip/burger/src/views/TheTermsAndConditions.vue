<script>

</script>

<template>
  <div class="">Terms & Conditions</div>
</template>

<style lang="sass" scoped>

</style>