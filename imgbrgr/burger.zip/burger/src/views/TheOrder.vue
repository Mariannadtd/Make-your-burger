<script setup>
import jsonData from '/data.json';
import { ref, watch } from 'vue';
import Ingredient from '../components/UI/Ingredient.vue';
import Summary from '../components/Summary.vue';

const elements = ref(jsonData);
const ingredientCounts = elements.value.map(() => ref(0));
const selectedIngredients = ref([]);
const totalPrice = ref(0);
const forceUpdate = ref(0);

const incr = (index) => {
  ingredientCounts[index].value++;
  updateSelectedIngredients();
};

const decr = (index) => {
  if (ingredientCounts[index].value > 0) {
    ingredientCounts[index].value--;
    updateSelectedIngredients();
  }
};

const updateSelectedIngredients = () => {
  selectedIngredients.value = elements.value.filter((el, index) => ingredientCounts[index].value > 0);
  forceUpdate.value++; 
};

const updateTotalPrice = () => {
  totalPrice.value = selectedIngredients.value.reduce((total, ingredient) => total + ingredient.price * ingredientCounts[ingredient.id - 1].value, 0);
  totalPrice.value = parseFloat(totalPrice.value.toFixed(2));
};

watch(forceUpdate, () => {
  updateTotalPrice();
});

const totalMinutes = ref(0)
const totalOz = ref(0)
const totalCkal = ref(0)

const updatedTotalMinutes = () => {
  totalMinutes.value = selectedIngredients.value.reduce((total, ingredient) => total + ingredient.min * ingredientCounts[ingredient.id - 1].value, 0);
}

const updateTotalOz = () => {
  if (selectedIngredients.value.length > 0 && ingredientCounts.length > 0) {
    const totalOzValue = selectedIngredients.value.reduce((total, ingredient) => total + (ingredient.oz || 0) * (ingredientCounts[ingredient.id - 1]?.value || 0), 0);
    console.log('Total Ounces:', totalOzValue);
    totalOz.value = parseFloat(totalOzValue.toFixed(2));
  } else {
    totalOz.value = 0;
  }
}

const updateTotalCkal = () => {
  totalCkal.value = selectedIngredients.value.reduce((total, ingredient) => total + ingredient.kcal * ingredientCounts[ingredient.id - 1].value, 0);
}

watch(forceUpdate, () => {
  updatedTotalMinutes();
  updateTotalOz();
  updateTotalCkal();
});

</script>


<template>
  <section class="order">
    <div class="order__mid">
      <h1 class="order__title">Make Your Burger</h1>
      <div class="order__burger">
        <img class="order__burger-bg" src="../assets/img/bg_burger.svg" alt="">
        <div class="ingr">
          <img class="order__burger-bun" src="../assets/img/bun_bottom.png" alt="">
          <ul>
            <li v-for="ingredient in selectedIngredients" :key="ingredient.id">
              <img class="order__burger-ingredients" :src="ingredient.img" :alt="ingredient.name" />
            </li>
          </ul>
        </div>
      </div>
      <div class="summary">

        <Summary 
          :totalPrice="totalPrice"
          :totalMinutes="totalMinutes"
          :totalOz="totalOz"
          :totalCkal="totalCkal"
        />

      </div>   
    </div>
    <div>
      <ul class="order__list">
        <li v-for="(el, index) in elements" :key="el.id">
          <Ingredient :el="el" :count="ingredientCounts[index]" :onIncr="() => incr(index)" :onDecr="() => decr(index)"/>
        </li>
      </ul>
    </div>
  </section>
</template>

<style lang="sass" scoped>
.order
  &__title
    font-weight: 700
    font-size: 4.7rem
    position: relative
  &__mid
    display: flex
    align-items: center
    justify-content: space-between
  &__bun
    width: 10rem
    height: 10rem
  &__list
    display: flex
    justify-content: space-between
    align-items: center
  & li
    display: flex
    flex-direction: column
    align-items: center
    justify-content: center
  &__burger
    &-bg
      width: 75%
    &-bun
      width: 55%
      position: absolute
      top: -7rem
    &-ingredients
      width: 55%
.ingr
  position: relative
</style>