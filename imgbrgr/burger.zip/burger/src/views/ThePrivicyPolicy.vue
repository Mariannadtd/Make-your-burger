<script>

</script>

<template>
  <div class="">Privicy Policy</div>
</template>

<style lang="sass" scoped>

</style>