<script setup>
import { ref } from 'vue';
import Modal from './Modal.vue';
import Button from '../components/UI/Button.vue'

const links = ref([
  { name: 'Discover', href: '/' },
  { name: 'Make Your Burger', href: '/order' }
]);

const calls = ref([
  { name: 'Call me Back', alias: 1, class: 'call__me' },
  { name: '8 800 555-35-35', alias: 2 }
]);

const showModal = ref(false);
const btnSecond = 'second'
</script>

<template>
  <header class="header">
    <div>
      <a class="logo">
        <img src="../assets/img/logo.svg" alt="logo">
      </a>
      <nav class="nav">
        <router-link  
          v-for="link in links" 
          :key="link.name"
          :to="link.href"
        >
          {{ link.name }}
        </router-link>
      </nav>
    </div>

    <div>
      <ul class="call" v-for="call in calls" :key="call.name">
        <li v-if="call.class">
          <Button @click="showModal = true" :third="btnSecond">
            <template v-slot:third>
              {{ call.name }}
            </template>
          </Button>
        </li>
        <li v-else>
          <span>{{ call.name }}</span>
        </li>
      </ul>
      <a href="#">
        <img class="user" src="../assets/img/user_head.png" alt="">
      </a>
      <Modal :showModal="showModal" @closeModal="showModal = false" />
    </div>
  </header>
</template>

<style lang="sass" scoped>
header
  display: flex
  align-items: center
  justify-content: space-between
  font-weight: 500
  font-size: 1.6rem
  div
    display: flex
    align-items: center

.logo 
  display: inline-block
  background-color: var(--main)
  padding: 2rem
  border-radius: 5rem


.call
  display: flex

.user
  width: rem
  height: 2rem
</style>