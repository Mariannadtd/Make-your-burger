<script setup>
const emit = defineEmits(['click'])

const props = defineProps({
  primary: String,
  second: String,
  third: String
})

const clickOnButton = () => {
  emit('click')
}
</script>

<template>
  <button class="button" :class="['btn', primary ? `btn_${primary}` : '', second ? `btn_${second}` : '', third ? `btn_${third}` : '']" @click="clickOnButton">
    <slot name="primary"></slot>
    <slot name="second"></slot>
    <slot name="third"></slot>
  </button>
</template>

<style scoped  lang="sass">
.btn
  border: none
  cursor: pointer
  text-decoration: none
  outline: none
  border-radius: 100rem
  color: white
  font-weight: 700 
  &_primary
    display: block
    background-color: var(--blue)
    padding: 2rem 
    height: 10rem
    width: 10rem
    position: absolute
    margin-right: 40rem
    margin-bottom: -25rem
    z-index: 5
  &_second
    padding: 1rem
    background-color: #FFDEDE
    color: red
  &_third
    padding: 1rem
    background-color: var(--blue)
</style>