<script setup>
const props = defineProps(['el', 'count', 'onIncr', 'onDecr']);
const emit = defineEmits();

const selectedIngredient = () => {
  emit('selectIngredient');
};
</script>

<template>
  <div @click="selectedIngredient">
    <img class="order__list_img" v-lazy="props.el.img" :alt="props.el.name" />
    <span>{{ props.el.name }}</span>
    <div class="">
      <button @click="props.onDecr">-</button>
      <span>{{ props.count }}</span> 
      <button @click="props.onIncr">+</button>
    </div>
  </div>
</template>

<style scoped lang="sass">
.order
  &__list
    &_img
      width: 9rem !important
</style>