<script setup>
const props = defineProps({
  totalPrice: Number,
  totalMinutes: Number,
  totalOz: Number,
  totalCkal: Number
})
</script>

<template>
<h3>Summary</h3>
<div class="div">
  <div class="price">
    $
    <div v-if="totalPrice > 0">
      {{ totalPrice }}
    </div>
    <div v-else>
      0.00
    </div>
  </div>
  <button>
    Checkout
  </button>
</div>
<span>Build a $10 Burger and Get a Gift</span>
<ul>
  <li>
    {{ totalMinutes }} min
  </li>
  <li>
    {{ totalOz }} oz
  </li>
  <li>
    {{ totalCkal }} kcal
  </li>
</ul>
</template>

<style lang="sass" scoped>

</style>